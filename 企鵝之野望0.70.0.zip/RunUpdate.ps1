﻿
# 設置腳本編碼為 UTF-8，解決中文顯示問題
[Console]::OutputEncoding = [System.Text.Encoding]::UTF8

Write-Host "==============================================" -ForegroundColor Cyan
Write-Host "          企鵝之野望 - 更新程序          " -ForegroundColor Cyan
Write-Host "==============================================" -ForegroundColor Cyan
Write-Host ""
Write-Host "正在執行更新，請勿關閉此視窗..." -ForegroundColor Yellow
Write-Host ""

# 記錄到日誌文件
$logFile = "update_log.txt"
"[$(Get-Date)] 開始更新過程" | Out-File -FilePath $logFile -Encoding utf8

# 檢查更新文件
if (-not (Test-Path "update.zip")) {
    Write-Host "錯誤: 找不到更新文件 'update.zip'" -ForegroundColor Red
    "[$(Get-Date)] 錯誤: 找不到更新文件" | Out-File -Append -FilePath $logFile -Encoding utf8
    Write-Host ""
    Write-Host "按任意鍵退出..." -ForegroundColor Yellow
    $null = $Host.UI.RawUI.ReadKey("NoEcho,IncludeKeyDown")
    exit 1
}

# 顯示文件大小
$fileSize = (Get-Item "update.zip").Length / 1KB
Write-Host "找到更新文件，大小: $([Math]::Round($fileSize, 2)) KB" -ForegroundColor Green
"[$(Get-Date)] 找到更新文件，大小: $([Math]::Round($fileSize, 2)) KB" | Out-File -Append -FilePath $logFile -Encoding utf8

# 等待原應用程式退出
Write-Host ""
Write-Host "正在等待原應用程式退出..." -ForegroundColor Yellow
Start-Sleep -Seconds 2

# 解壓縮文件
try {
    Write-Host ""
    Write-Host "正在解壓縮更新文件..." -ForegroundColor Yellow
    "[$(Get-Date)] 開始解壓縮更新文件" | Out-File -Append -FilePath $logFile -Encoding utf8
    
    Add-Type -AssemblyName System.IO.Compression.FileSystem
    $zip = [System.IO.Compression.ZipFile]::OpenRead("update.zip")
    Write-Host "更新包含 $($zip.Entries.Count) 個文件" -ForegroundColor Cyan
    
    # 手動解壓縮文件，而不使用 ExtractToDirectory 方法
    Write-Host "正在解壓文件..." -ForegroundColor Yellow
    foreach ($entry in $zip.Entries) {
        $targetPath = [System.IO.Path]::Combine(".", $entry.FullName)
        $targetDir = [System.IO.Path]::GetDirectoryName($targetPath)
        
        # 確保目標目錄存在
        if (-not [System.IO.Directory]::Exists($targetDir)) {
            [System.IO.Directory]::CreateDirectory($targetDir)
        }
        
        # 如果是文件（不是目錄）才解壓
        if (-not $entry.FullName.EndsWith('/')) {
            # 檢查文件是否已存在，如果存在則刪除
            if ([System.IO.File]::Exists($targetPath)) {
                try {
                    [System.IO.File]::Delete($targetPath)
                } catch {
                    # 使用 ${} 括號正確引用變數，避免與冒號衝突
                    Write-Host "無法刪除文件 ${targetPath}: $_" -ForegroundColor Yellow
                }
            }
            
            # 解壓文件
            try {
                $entryStream = $entry.Open()
                $targetStream = [System.IO.File]::Create($targetPath)
                $entryStream.CopyTo($targetStream)
                $targetStream.Close()
                $entryStream.Close()
            } catch {
                # 同樣使用 ${} 括號
                Write-Host "解壓文件 ${entry.FullName} 失敗: $_" -ForegroundColor Red
                throw
            }
        }
    }
    
    $zip.Dispose()
    Write-Host "解壓縮完成！" -ForegroundColor Green
    "[$(Get-Date)] 解壓縮完成" | Out-File -Append -FilePath $logFile -Encoding utf8
}
catch {
    Write-Host "解壓縮失敗: $($_.Exception.Message)" -ForegroundColor Red
    "[$(Get-Date)] 解壓縮失敗: $($_.Exception.Message)" | Out-File -Append -FilePath $logFile -Encoding utf8
    Write-Host ""
    Write-Host "按任意鍵退出..." -ForegroundColor Yellow
    $null = $Host.UI.RawUI.ReadKey("NoEcho,IncludeKeyDown")
    exit 1
}

# 刪除更新文件
Write-Host ""
Write-Host "正在刪除更新文件..." -ForegroundColor Yellow
try {
    Remove-Item "update.zip" -Force
    Write-Host "更新文件已刪除" -ForegroundColor Green
    "[$(Get-Date)] 更新文件已刪除" | Out-File -Append -FilePath $logFile -Encoding utf8
}
catch {
    Write-Host "警告: 無法刪除更新文件: $($_.Exception.Message)" -ForegroundColor Yellow
    "[$(Get-Date)] 警告: 無法刪除更新文件" | Out-File -Append -FilePath $logFile -Encoding utf8
}

# 寫入更新成功標記
"更新成功於 $(Get-Date)" | Out-File -FilePath "update_success.txt" -Encoding utf8
"[$(Get-Date)] 寫入更新成功標記" | Out-File -Append -FilePath $logFile -Encoding utf8

# 重新啟動應用程式
Write-Host ""
Write-Host "正在重新啟動應用程式..." -ForegroundColor Yellow
"[$(Get-Date)] 準備重新啟動應用程式" | Out-File -Append -FilePath $logFile -Encoding utf8

try {
    Start-Process "NOBApp.exe"
    Write-Host "應用程式已重新啟動" -ForegroundColor Green
    "[$(Get-Date)] 應用程式已重新啟動" | Out-File -Append -FilePath $logFile -Encoding utf8
}
catch {
    Write-Host "警告: 無法直接啟動 NOBApp.exe，嘗試尋找其它可執行文件..." -ForegroundColor Yellow
    
    $exeFiles = Get-ChildItem -Path "." -Filter "*.exe" | Where-Object { $_.Name -ne "NOBApp.exe" }
    if ($exeFiles.Count -gt 0) {
        $exePath = $exeFiles[0].FullName
        Write-Host "找到可能的可執行文件: $($exeFiles[0].Name)" -ForegroundColor Green
        Start-Process $exePath
        "[$(Get-Date)] 啟動替代執行檔: $($exeFiles[0].Name)" | Out-File -Append -FilePath $logFile -Encoding utf8
    }
    else {
        Write-Host "警告: 無法找到可執行文件，請手動啟動應用程式" -ForegroundColor Red
        "[$(Get-Date)] 警告: 無法找到可執行文件" | Out-File -Append -FilePath $logFile -Encoding utf8
    }
}

# 結束
Write-Host ""
Write-Host "==============================================" -ForegroundColor Green
Write-Host "                更新成功完成!                " -ForegroundColor Green
Write-Host "==============================================" -ForegroundColor Green
Write-Host ""
"[$(Get-Date)] 更新過程完成" | Out-File -Append -FilePath $logFile -Encoding utf8

Write-Host "按任意鍵關閉此視窗..." -ForegroundColor Yellow
$null = $Host.UI.RawUI.ReadKey("NoEcho,IncludeKeyDown")
